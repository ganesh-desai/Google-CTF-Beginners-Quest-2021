k = open("step9.bin").read().splitlines()

for ln in k:
	print(chr(len(ln) -4), end = "")
